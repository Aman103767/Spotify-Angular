import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ProductsComponent } from './products/products.component';
import { ProductService } from './products/product.service';
import { Product } from './models/product.model';
import { ProductComponent } from './products/product/product.component';
import { CartComponent } from './cart/cart.component';
import { CustomerComponent } from './customer/customer.component';
import { RouterModule, Routes } from '@angular/router';
import { FetchCustomerListComponent } from './customer/fetch-customer-list/fetch-customer-list.component';
import { UpdateCustomerComponent } from './customer/update-customer/update-customer.component';


const appRoutes : Routes = [
    { path: 'customer',component : CustomerComponent },
    { path: 'products', component : ProductsComponent },
    { path: 'customerList',component : FetchCustomerListComponent },
    { path: 'updateCustomer/:customerId',component: UpdateCustomerComponent}
];

@NgModule({
  declarations: [AppComponent,HeaderComponent, ProductsComponent,ProductComponent, CartComponent, CustomerComponent, FetchCustomerListComponent, UpdateCustomerComponent],
  imports: [BrowserModule, FormsModule, HttpClientModule,RouterModule.forRoot(appRoutes)],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {}
