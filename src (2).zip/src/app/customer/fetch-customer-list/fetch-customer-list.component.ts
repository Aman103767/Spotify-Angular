import { HttpClient } from '@angular/common/http';
import { Component, Injectable, OnInit } from '@angular/core';
import { map } from 'rxjs';
import { Customer } from 'src/app/models/customer.model';
import { ProductService } from 'src/app/products/product.service';
@Injectable()
@Component({
  selector: 'app-fetch-customer-list',
  templateUrl: './fetch-customer-list.component.html',
  styleUrls: ['./fetch-customer-list.component.css']
})
export class FetchCustomerListComponent implements OnInit{
  customers : Customer [] = [];
  constructor(private productService : ProductService) {

  }
 ngOnInit(): void {
   this.getCustomers()
 }
 private getCustomers(){
  this.productService.getCustomerList().subscribe(data => {
    this.customers = data;
  })
 }
 public customerId : number;
 getCustomerId(customerId : number){
   this.customerId = customerId;
 }
 
  

}
