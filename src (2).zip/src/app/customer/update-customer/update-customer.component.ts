import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Customer } from 'src/app/models/customer.model';
import { ProductService } from 'src/app/products/product.service';
import { FetchCustomerListComponent } from '../fetch-customer-list/fetch-customer-list.component';

@Component({
  selector: 'app-update-customer',
  templateUrl: './update-customer.component.html',
  styleUrls: ['./update-customer.component.css']
})
export class UpdateCustomerComponent implements OnInit {
  customerId : number;
  customer : Customer = new Customer();
  constructor(private productService : ProductService,
    private route:ActivatedRoute){

  }
  
   ngOnInit(): void {
  //   this.route.params.subscribe(params => {
  //     this.customerId = +params['customerId'];
  //     console.log(this.customerId);
  //   });
    this.productService.getCustomerById(1).subscribe(data =>{
      this.customer = data;
      console.log(data);
    },error => console.log(error));
    
   }


 onSubmit(){
 // this.updateCustomer();
 }



}
