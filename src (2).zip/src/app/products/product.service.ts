import { HttpClient } from "@angular/common/http";
import { CssSelector } from "@angular/compiler";
import { EventEmitter, Injectable, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { Customer } from "../models/customer.model";
import { Product } from "../models/product.model";
@Injectable() 
export class ProductService {
   productSelected = new EventEmitter<Product>();

   products: Product[] = [];
   cartProducts : Product [] = [];
  //  customerId : number;
  //  quantity : number;
  //  productId : number;
  //  addtocartMes : string;

constructor(private http: HttpClient) { 
 
}
getProductList(): Observable<Product[]>{
  return this.http.get<Product[]>('http://localhost:8888/Customer/getAllProduct');
}


public addToCartfun(product : Product){
  this.http.get<String>(`http://localhost:8888/Customer/cart/${15}/${1}/${product.productId}`)
  
  .pipe(map(responseData => {
    console.log(responseData); 
     return responseData;
  })).subscribe(ResponseData=>{
   console.log(ResponseData); 
  })
  
}

getCustomerList(): Observable<Customer[]> {
  return this.http.get<Customer[]>('http://localhost:8888/admin/viewAll');
}
getCustomerById(id : number) : Observable<Customer> {
  return this.http.get<Customer>(`http://localhost:8888/admin/viewById/${id}`)
}

public viewAllProductCart(){

}

}
