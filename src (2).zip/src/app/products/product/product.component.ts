import { Component, Injectable, Input } from '@angular/core';
import { Product } from 'src/app/models/product.model';
import { ProductService } from '../product.service';
Injectable()
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers: [ProductService]
})
export class ProductComponent {
@Input() product : Product;
cartProduct : Product;
constructor(public productService: ProductService){

}
onSelected(){

  this.productService.productSelected.emit(this.product);

}
addToCart(product : Product){
      this.cartProduct = product
      this.productService.addToCartfun(product);
}
  

}
