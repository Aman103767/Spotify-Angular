import { Component, OnInit } from '@angular/core';
import { Pagination } from 'src/app/models/pagination.model';
import { ProductService } from '../product.service';
import { ProductsComponent } from '../products.component';

@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css']
})
export class PaginationComponent implements OnInit{
  pagination : Pagination;

  constructor(private productService : ProductService,private productsCom : ProductsComponent
    ){

  }
  
  ngOnInit(): void {
    
    
  }
  goToprev(){

  }
  goToNext(){

  }
  method(){
    const list = document.getElementById('my-list');
    list.addEventListener('click', (event: MouseEvent) => {
      const element = event.target as HTMLElement;
      const text = element.textContent.trim();
      console.log(text); // Output: The text of the clicked element
      if(text == "Previous"){
        const elements = document.querySelectorAll('.myClass');
        for (let i = 0; i < elements.length; i++) {
          const element = elements[i];
          const currentText = parseInt(element.textContent || '0');
          const newText = currentText - 1;
          element.textContent = newText.toString();
        }
        
      }
      else{
        const elements = document.querySelectorAll('.myClass');
for (let i = 0; i < elements.length; i++) {
  const element = elements[i];
  const currentText = parseInt(element.textContent || '0');
  const newText = currentText + 1;
  element.textContent = newText.toString();
}

      }
      this.productsCom.innerText(text);
    });
  }



}
