import { Component, Injectable, OnInit } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Pagination } from 'src/app/models/pagination.model';
import { Product } from 'src/app/models/product.model';
import { ProductService } from '../product.service';
import { ProductsComponent } from '../products.component';
@Injectable()
@Component({
  selector: 'app-pagination',
  templateUrl: './pagination.component.html',
  styleUrls: ['./pagination.component.css']
})
export class PaginationComponent implements OnInit{
  pagination : Pagination;
  private currentPageSubject = new BehaviorSubject<number>(0);
  currentPage$ = this.currentPageSubject.asObservable();

  constructor(public productsCom : ProductsComponent
    ,public productService : ProductService){

  }
 
  
  ngOnInit(): void {
    
    this.productService.getPaginationData(0,3,"string","productName",false).subscribe(data =>{
      this.pagination = data;
      console.log(this.pagination);
     this.currentPageSubject.next(data.pageable.pageNumber);
      })
  }
  goToPage(name? : string , pageNumber : number = 0) {
    this.productService.getPaginationData(pageNumber,3,"string","productName",false).subscribe(data =>{
      this.pagination = data;
      console.log(this.pagination);
      this.currentPageSubject.next(pageNumber);
      this.productsCom.updateProducts(this.pagination.content);
     
      })
  }
  goToNextOrPreviousPage(direction? : string,name? : string){
    this.goToPage(name,direction === 'forward' ? this.currentPageSubject.value + 1 :this.currentPageSubject.value-1) ;
  }


}
