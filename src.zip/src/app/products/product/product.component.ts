import { Component, Input } from '@angular/core';
import { Product } from 'src/app/models/product.model';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers: [ProductService]
})
export class ProductComponent {
@Input() product : Product;
constructor(public productService: ProductService){

}
onSelected(){

  this.productService.productSelected.emit(this.product);

}
  

}
