import { Component, Injectable, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { FordetailsAddtocartComponent } from 'src/app/cart/fordetails-addtocart/fordetails-addtocart.component';
import { Product } from 'src/app/models/product.model';
import { ProductService } from '../product.service';
Injectable()
@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
  providers: [ProductService,FordetailsAddtocartComponent]
})
export class ProductComponent {
@Input() product : Product;
id : number;
constructor(public productService: ProductService,private router : ActivatedRoute,private fordetialsCart: FordetailsAddtocartComponent){

}
onSelected(){

  this.productService.productSelected.emit(this.product);

}


  

}
