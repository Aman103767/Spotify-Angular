import { HttpClient } from "@angular/common/http";
import { EventEmitter, Injectable, OnInit } from "@angular/core";
import { map } from "rxjs/operators";
import { Product } from "../models/product.model";
@Injectable() 
export class ProductService {
   productSelected = new EventEmitter<Product>();

   products: Product[] = [];

constructor(private http: HttpClient) { }
public fetchProducts() {
  this.http.get<Product[]>('http://localhost:8888/Customer/getAllProduct')
  .pipe(map(responseData => {
     return responseData;
  })).subscribe(products =>{
    this.products = products;
  })
  
}

}
