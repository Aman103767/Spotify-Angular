import { HttpClient } from "@angular/common/http";
import { CssSelector } from "@angular/compiler";
import { EventEmitter, Injectable, OnInit } from "@angular/core";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";
import { Address } from "../models/address.model";
import { CartProduct } from "../models/cartProduct.model";
import { Customer } from "../models/customer.model";
import { Orders } from "../models/order.model";

import { Product } from "../models/product.model";
@Injectable() 
export class ProductService {
   productSelected = new EventEmitter<Product>();
   OrderSelected = new EventEmitter<Orders>();

   //products: Product[] = [];
  // cartProducts : Product [] = [];
  //  customerId : number;
  //  quantity : number;
  //  productId : number;
  //  addtocartMes : string;

constructor(private http: HttpClient) { 
 
}
getProductList(): Observable<Product[]>{
  return this.http.get<Product[]>('http://localhost:8888/Customer/getAllProduct');
}


public addToCartfun(product : Product){
  this.http.get<String>(`http://localhost:8888/Customer/cart/${15}/${1}/${product.productId}`)
  
  .pipe(map(responseData => {
    console.log(responseData); 
     return responseData;
  })).subscribe(ResponseData=>{
   console.log(ResponseData); 
  })
  
}

getCustomerList(): Observable<Customer[]> {
  return this.http.get<Customer[]>('http://localhost:8888/admin/viewAll');
}
getCustomerById(id : number) : Observable<Customer> {
  return this.http.get<Customer>(`http://localhost:8888/admin/viewById/${id}`)
}
updateCustomer(id: number ,customer : Customer): Observable<Object>{
  return this.http.put(`http://localhost:8888/Customer/update/${id}`,customer);

}
deleteCustomer(id: number) : Observable<Object>{
  return this.http.delete(`http://localhost:8888/Customer/delete/${id}`);
}
createProduct(product: Product): Observable<Object>{
  return this.http.post('http://localhost:8888/product/create',product);
}
getProductById(id : number): Observable<Product>{
  return this.http.get<Product>(`http://localhost:8888/admin/getProductById/${id}`);
}
updateProduct(id: number,product: Product): Observable<Object>{
  return this.http.put(`http://localhost:8888/product/updateProduct/${id}`,product);
}
deleteProduct(id: number) : Observable<Object>{
  return this.http.delete(`http://localhost:8888/admin/removeProduct/${id}`);
}
getSortedProductList(): Observable<Product[]>{
  return this.http.get<Product[]>('http://localhost:8888/Customer/getSortedProductByAnyFieldAsc/price');
}
getSortedProductListDesc(): Observable<Product[]>{
  return this.http.get<Product[]>('http://localhost:8888/Customer/getSortedProductByAnyFieldDsc/price');
}
getSortedAnyField(field : string): Observable<Product[]>{
  return this.http.get<Product[]>(`http://localhost:8888/Customer/getSortedProductByAnyFieldAsc/${field}`);
}
addtocart(customerId : number,productId : number) : Observable<Object>{
  return this.http.get<Object>(`http://localhost:8888/Customer/cart/${customerId}/1/${productId}`);
}
getallProductFromCart(customerId : number) : Observable<CartProduct []>{
  return this.http.get<CartProduct []>(`http://localhost:8888/Customer/getAllProductAddedInCart/${customerId}`);
}
updateQuantityCart(productId: number ,quantity : number, customerId : number) : Observable<Object>{
  return this.http.get<Object>(`http://localhost:8888/Customer/updatingQuantity/${productId}/${quantity}/${customerId}`);
}
deleteProductFromCart(productId: number,customerId: number) : Observable<String>{
  return this.http.delete<String>(`http://localhost:8888/Customer/removeProductFromCart/${productId}/${customerId}`);
}
getAllOrder(customerId : number): Observable<Orders []>{
  return this.http.get<Orders []>(`http://localhost:8888/Customer/getAllOrdersByCustomer/${customerId}`);
}
Order(customerId:number,address : Address): Observable<Object>{
  return this.http.post(`http://localhost:8888/order/orderProduct/${customerId}`,address);
}
getOrderById(orderId : number) : Observable<Orders>{
  return this.http.get<Orders>(`http://localhost:8888/order/getOrderById/${orderId}`)
  
}
}
