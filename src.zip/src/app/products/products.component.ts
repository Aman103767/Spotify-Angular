import { Component, Injector, OnInit } from '@angular/core';
import { Product } from '../models/product.model';
import { ProductService } from './product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  
})
export class ProductsComponent implements OnInit {
  field : string;
  products : Product [] = [];
  constructor(private productService : ProductService) {

  }
 ngOnInit(): void {
   this.getProducts()
 }
 private getProducts(){
  this.productService.getProductList().subscribe(data => {
    this.products = data;
  })
 }
 ascSort(){
 this.productService.getSortedProductList().subscribe(data =>{
  this.products = data;
 })

 
 }
 dscSort(){
  this.productService.getSortedProductListDesc().subscribe(data =>{
    this.products = data;
   })
  

  }
 onSubmit(){
  this.productService.getSortedAnyField(this.field).subscribe(data =>{
    this.products = data;
   })
 }
 
  

}