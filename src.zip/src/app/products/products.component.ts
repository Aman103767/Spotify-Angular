import { Component, Injectable, Injector, OnInit } from '@angular/core';
import { Content } from '../models/content.model';
import { GetProduct } from '../models/getProduct.model';
import { Pagination } from '../models/pagination.model';
import { ProductService } from './product.service';
Injectable()
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  
})
export class ProductsComponent implements OnInit {
  field : string;
  products : Content [] = [];
  name : string;
  pageNumber : number = 0;
  direction: boolean =false;
  pagination : Pagination;
  constructor(private productService : ProductService) {

  }
 ngOnInit(): void {
   this.getProducts()
 }
 private getProducts(){
  if(this.field == undefined){
    this.field = "productName";
  }
  if(this.name == undefined){
    this.productService.getPaginationData(this.pageNumber,3,"string",this.field,this.direction).subscribe(data =>{
      this.pagination = data;
      this.products = this.pagination.content;
      console.log(this.pagination);
   
     
      })
  }else{
    this.productService.getPaginationData(this.pageNumber,3,this.name,this.field,this.direction).subscribe(data =>{
      this.pagination = data;
      this.products = this.pagination.content;
      console.log(this.pagination);
     
      })
  }
 }
  updateProducts(products : Content []){
    this.products = products;
  }
 filter(){
  if(this.field == undefined){
    this.field = "productName";
  }
  if(this.name == undefined || this.name == ""){
    this.productService.getPaginationData(this.pageNumber,3,"string",this.field,this.direction).subscribe(data =>{
      this.pagination = data;
      this.products = this.pagination.content;
      console.log(this.pagination);
    console.log("aman");
     
      })
  }else{
    this.productService.getPaginationData(this.pageNumber,3,this.name,this.field,this.direction).subscribe(data =>{
      this.pagination = data;
      this.products = this.pagination.content;
      console.log(this.pagination);
      console.log("sai");
     
      })
  }
  
}
sortByField(){
  if(this.field == undefined || this.field == ""){
    this.field = "productName";
  }
  if(this.name == undefined){
    this.productService.getPaginationData(this.pageNumber,3,"string",this.field,this.direction).subscribe(data =>{
      this.pagination = data;
      this.products = this.pagination.content;
      console.log(this.pagination);
   
     
      })
  }else{
    this.productService.getPaginationData(this.pageNumber,3,this.name,this.field,this.direction).subscribe(data =>{
      this.pagination = data;
      this.products = this.pagination.content;
      console.log(this.pagination);
     
      })
  }
}
 sortBy(field :string){
    this.field = field;
    this.sortByField();
 }
  order(flag : boolean){
    this.direction = flag;
    this.sortByField();
  }

}