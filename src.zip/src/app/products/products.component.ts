import { Component, Injector, OnInit } from '@angular/core';
import { Product } from '../models/product.model';
import { ProductService } from './product.service';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  providers: [ProductService]
})
export class ProductsComponent implements OnInit {

  products: Product [] = [];
  public ngOnInit(): void {
    this.productService.fetchProducts();
  }
  constructor(public productService: ProductService) {
  }
  fetch(){
   this.products = this.productService.products;
   console.log(this.productService.products);
   
  }
  
 
 
  }
  

