import { Component, Injectable, Injector, OnInit } from '@angular/core';
import { Content } from '../models/content.model';
import { GetProduct } from '../models/getProduct.model';
import { Pagination } from '../models/pagination.model';
import { ProductService } from './product.service';
Injectable()
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],
  
})
export class ProductsComponent implements OnInit {
  field : string;
  products : Content [] = [];
  name : string;
  pageNumber : number = 0;
  direction: boolean =false;
  pagination : Pagination;
  constructor(private productService : ProductService) {

  }
 ngOnInit(): void {
   this.getProducts()
 }
 private getProducts(){
  this.productService.getProductList().subscribe(data => {
    this.products = data;
    console.log(this.products)
    
  })
 }
 ascSort(){
 this.productService.getSortedProductList().subscribe(data =>{
  //this.products=data;
 })

 
 }
 dscSort(){
  if(this.field == undefined){
    this.field = "productName";
  }
  if(this.name == ""){
    this.name = " ";
  }
  this.direction = true;
   this.productService.getPaginationData(this.pageNumber,2,this.name,this.field,this.direction).subscribe(data =>{
   this.pagination = data;
   this.products = this.pagination.content;
   console.log(this.pagination);
  
   })
  

  }
  innerText(text: string){
    if(text == "Next"){
         this.pageNumber++;   
    }else if(text == "Previous"){
        this.pageNumber--;   
    }
    
    else{
      this.pageNumber = +text;
    }
    if(this.field == undefined){
      this.field = "productName";
    }
    if(this.name == ""){
      this.name = " ";
    }
     this.productService.getPaginationData(this.pageNumber,1,this.name,this.field,this.direction).subscribe(data =>{
     this.pagination = data;
     this.products = this.pagination.content;
     console.log(this.pagination);
    
     })
  }
  onInput(event : any){
    if(this.field == undefined){
      this.field = "productName";
    }
    if(this.name == ""){
      this.name = " ";
    }
     this.productService.getPaginationData(this.pageNumber,1,this.name,this.field,this.direction).subscribe(data =>{
     this.pagination = data;
     this.products = this.pagination.content;
     console.log(this.pagination);
    
     })
  }

 
  

}