export class LoginForm{
    password : string;
    username : string;
  
}