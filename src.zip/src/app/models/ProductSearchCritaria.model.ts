import { Product } from "./product.model";

export class ProductSearchCritaria{
    product : Product;
}