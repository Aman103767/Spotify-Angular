export class CartProduct{
id : number;
productId : number;
imagePath : string;
productName : string;
price : number;
dimension : number;
manufacturer: string;
quantity: number;

}