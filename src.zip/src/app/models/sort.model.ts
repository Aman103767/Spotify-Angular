export class Sort{
    empty : boolean;
    sorted: boolean;
    unsorted : boolean;
}