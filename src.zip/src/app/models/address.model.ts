export class Address{
    addressId : number;
    buildingNo : string;
    city : string;
    state : string;
    country : string;
    pincode : string;
}