export class PaginationDTO {
 pageNumber : number = 0;
 pageSize : number = 10;
 name : string ;
 sortBy : string;
 direction : boolean;
 

}