export class ProductDto{
    productId : number;
    imagePath : string;
    productName : string;
    price : number;
    dimension : string;
    manufacturer : string;
    quantity : number;
    id: number;
}