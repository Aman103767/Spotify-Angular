import { Component, Injectable, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Orders } from 'src/app/models/order.model';
import { ProductService } from 'src/app/products/product.service';
@Injectable()
@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {
   order : Orders;
   id : number;
 ngOnInit(){
 this.orderDetails();
 }
 constructor(private productService : ProductService,private router : ActivatedRoute){}
 orderDetails(){
  this.id = this.router.snapshot.params['id'];
  this.productService.getOrderById(this.id).subscribe(data =>{
    this.order = data;
    console.log(data);
  },error => console.log(error));

  }

}
