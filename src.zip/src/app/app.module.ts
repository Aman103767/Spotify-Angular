import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';


import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { ProductsComponent } from './products/products.component';
import { ProductService } from './products/product.service';
import { Product } from './models/product.model';
import { ProductComponent } from './products/product/product.component';
import { CartComponent } from './cart/cart.component';
import { CustomerComponent } from './customer/customer.component';
import { RouterModule, Routes } from '@angular/router';
import { FetchCustomerListComponent } from './customer/fetch-customer-list/fetch-customer-list.component';
import { UpdateCustomerComponent } from './customer/update-customer/update-customer.component';
import { CustomerDetailsComponent } from './customer/customer-details/customer-details.component';
import { CreateProductComponent } from './products/create-product/create-product.component';
import { ProductListComponent } from './products/product-list/product-list.component';
import { UpdateProductComponent } from './products/update-product/update-product.component';
import { FordetailsAddtocartComponent } from './cart/fordetails-addtocart/fordetails-addtocart.component';
import { OrdersComponent } from './orders/orders.component';
import { OrderComponent } from './orders/order/order.component';
import { AddressComponent } from './customer/address/address.component';
import { OrderDetailsComponent } from './orders/order/order-details/order-details.component';



const appRoutes : Routes = [
    { path: 'customer',component : CustomerComponent },
    { path: 'products', component : ProductsComponent },
    { path: 'customerList',component : FetchCustomerListComponent },
    { path: 'updateCustomer/:id',component: UpdateCustomerComponent},
    { path: 'customer-details/:id',component : CustomerDetailsComponent},
    { path: 'createProduct',component : CreateProductComponent},
    { path: 'productList',component : ProductListComponent },
    { path : 'updateProduct/:id', component : UpdateProductComponent},
    { path : 'forCartDetails/:id', component : FordetailsAddtocartComponent},
    { path : 'cart',component: CartComponent},
    { path : 'orders',component:OrdersComponent},
    { path : 'address',component: AddressComponent},
    { path : 'orderDetails/:id',component : OrderDetailsComponent}

];

@NgModule({
  declarations: [AppComponent,HeaderComponent,
     ProductsComponent,ProductComponent,
      CartComponent, CustomerComponent, 
      FetchCustomerListComponent, UpdateCustomerComponent,
      CustomerDetailsComponent, CreateProductComponent,
       ProductListComponent, UpdateProductComponent,
        FordetailsAddtocartComponent,
        OrderComponent,OrdersComponent, AddressComponent, OrderDetailsComponent],
  imports: [BrowserModule, FormsModule, 
    HttpClientModule,RouterModule.forRoot(appRoutes)],
  providers: [CartComponent,FordetailsAddtocartComponent,OrderDetailsComponent],
  bootstrap: [AppComponent]
})
export class AppModule {}
