import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';
import { Customer } from './models/customer.model';
import { ProductService } from './products/product.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: [ProductService]
})
export class AppComponent {
  title = 'E-Commerce';
  loadedPosts = [];
  customers : Customer [] = [];

  constructor(private http: HttpClient,private productService : ProductService) {}

  ngOnInit() {
    this.fetchPosts();
    
  }
  

  onCreatePost(postData: { name: string; email: string ; mobileNumber : String; password : String}) {
   
    this.http.post('http://localhost:8888/Customer/create',postData).subscribe(response => {
      console.log(response);
    console.log(postData);
  });
  }

  onFetchPosts() {
    // Send Http request
    this.fetchPosts();
    this.productService.fetchProducts;
  }

  onClearPosts() {
    // Send Http request
  }
  private fetchPosts(){
   this.http.get('http://localhost:8888/admin/viewAll').subscribe(customer =>{
         console.log(customer);
         
         
   }); 
  }
}
